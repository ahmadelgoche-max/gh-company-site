GH COMPANY starter site

Included:
- index.html
- assets/gh-company-logo.png
- assets/gh-company-banner.png

Preview:
Open index.html in a browser.

Publish free using GitHub Pages:
1. Sign in/create a GitHub account.
2. Create a public repository named gh-company-site.
3. Upload index.html and the assets folder.
4. Go to Settings > Pages.
5. Choose Deploy from a branch, branch main, folder /(root), then Save.

Before publishing:
- Replace YOUR_EMAIL@example.com in index.html with the business email you want to publish.
- Review the spelling GH ACAMING; the supplied brand image spells it this way.
- This is a brand website starter, not proof of legal company registration.
- The contact form opens an email app only after a real recipient email is configured.
